package dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import entities.Persona;

public class DaoMySQL extends BasicDao implements IDaoMySQL{

	public DaoMySQL(String dbAddress, String user, String password) {
		super(dbAddress, user, password);
	}

	@Override
	public List<Persona> persone() {
		// Questa sar� la lista che sar� ritornata dal metodo
		List<Persona> ris = new ArrayList<>();
		
		// chiedo al metodo getall di occuparsi dell'interazione con il db
		// mi restituisce una lista di mappe
		List<Map<String, String>> maps = getAll("SELECT * FROM personas");
		
		// Itero la lista di mappe: ogni mappa contiene le propriet� di un oggetto
		for (Map<String, String> map : maps) {
			// utilizzzo il ccostruttore vuoto per creare la persona
			Persona p = new Persona();
			// utilizzo il fromMap per caricare le propriet� della persona
			p.fromMap(map);
			ris.add(p);
		}
		
		return ris;
	}

	@Override
	public Persona persona(int id) {
		Persona ris = null;
		
		// getOne mi ritorna una singola mappa
		Map<String, String> map = getOne("SELECT * FROM personas WHERE id = ?", id);
		
		if (map != null) {
			// creo l'oggetto
			ris = new Persona();
			// lo carico delle informazioni
			ris.fromMap(map);
		}
		
		return ris;
	}

	@Override
	public void addPersona(Persona persona) {
		execute("INSERT INTO personas (nome, ddn, stipendio) VALUES (?, ?, ?)", 
				persona.getNome(), persona.getDdn(), persona.getStipendio());		
	}

	@Override
	public void deletePersona(int id) {
		execute("DELETE FROM personas WHERE id = ?", id);
	}

	@Override
	public void updatePersona(Persona persona) {
		execute("UPDATE personas SET nome = ?, ddn = ?, stipendio = ? WHERE id = ?", 
				persona.getNome(), persona.getDdn(), persona.getStipendio(), persona.getId());		
	}

}
