package dao;

import java.util.List;

import entities.Persona;

public interface IDaoMySQL {

	List<Persona> persone();
	
	Persona persona(int id);
	
	void addPersona(Persona persona);
	
	void deletePersona(int id);
	
	void updatePersona(Persona persona);
}
