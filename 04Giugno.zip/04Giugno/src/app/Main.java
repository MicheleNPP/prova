package app;

public class Main {

	public static void main(String[] args) {
		// creo un oggetto di tipo App e invoco il metodo run()
		new App().run();
	}

}
