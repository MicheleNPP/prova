package app;

import dao.DaoMySQL;
import dao.IDaoMySQL;
import entities.Persona;

// Questa classe estender� ConsoleApp, quindi eredito tutti quanti i metodi come se fossero scritti
// in questa classe: ne posso fare uso senza dover importare ConsoleApp
public class App extends ConsoleApp{

	private static final String PASSWORD = "root";
	private static final String USERNAME = "root";
	private static final String DB_ADDRESS = "jdbc:mysql://localhost:3306/ormpro";

	@Override
	public void run() {
		IDaoMySQL dao = new DaoMySQL(DB_ADDRESS, USERNAME, PASSWORD);
		
		String cmd = "";
		
		do {
			// dobbiamo richiedere il comando all'utente
			cmd = nextLine("Inserire il comando");
			String ris = "";
			
			switch(cmd.toLowerCase()) {
			case "lista":
				ris = dao.persone().toString();
				break;
			case "persona":
				int id = nextInt("Inserire l'id", 
						"Valore non valido, per favore inserire un numero intero in cifre");
				// prima di restituire la persona, controllo se nel database
				// � stata trovata la persona con quell'id
				Persona trovata = dao.persona(id);
				if (trovata != null) {
					ris = trovata.toString();
				} else {
					ris = "Nessuna persona trovata con l'id " + id;
				}
				break;
			case "aggiungi":
				Persona daAggiungere = new Persona(0, 
													nextLine("Inserire il nome"), 
													nextLine("Inserire la data di nascita"), 
													nextInt("Inserire lo stipendio",
															"Valore non valido, per favore inserire un numero intero in cifre"));
				dao.addPersona(daAggiungere);
				ris = "Ok, aggiunto";
				break;
			case "cancella":
				id = nextInt("Inserire l'id", 
						"Valore non valido, per favore inserire un numero intero in cifre");
				dao.deletePersona(id);
				ris = "Ok, cancellato";
				break;
			case "modifica":
				Persona daMod = new Persona(nextInt("Inserire l'id", 
													"Valore non valido, per favore inserire un numero intero in cifre"), 
											nextLine("Inserire il nome"), 
											nextLine("Inserire la data di nascita"), 
											nextInt("Inserire lo stipendio",
													"Valore non valido, per favore inserire un numero intero in cifre"));
				dao.updatePersona(daMod);
				ris = "Ok, modificato";
				break;
			case "esci":
				ris = "Arrivederci";
				break;
			default:
				ris = "Che stai a d�?";
				break;
			}
			
			print(ris);
		} while(!cmd.equalsIgnoreCase("esci"));
	}

}















